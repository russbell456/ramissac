# Code analysis
## RamisSac Backend 
#### Version 1.0 

**By: Administrator**

*Date: 2026-05-19*

## Introduction
This document contains results of the code analysis of RamisSac Backend



## Configuration

- Quality Profiles
    - Names: Sonar way [Python]; 
    - Files: AZ49WxFOwfDAHyB10vu2.json; 


 - Quality Gate
    - Name: Sonar way
    - File: Sonar way.xml

## Synthesis

### Analysis Status

Reliability | Security | Security Review | Maintainability |
:---:|:---:|:---:|:---:
A | A | A | A |

### Quality gate status

| Quality Gate Status | OK |
|-|-|

Metric|Value
---|---
Reliability Rating on New Code|OK
Security Rating on New Code|OK
Maintainability Rating on New Code|OK


### Metrics

Coverage | Duplications | Comment density | Median number of lines of code per file | Adherence to coding standard |
:---:|:---:|:---:|:---:|:---:
68.5 % | 0.0 % | 2.5 % | 24.0 | 99.9 %

### Tests

Total | Success Rate | Skipped | Errors | Failures |
:---:|:---:|:---:|:---:|:---:
0 | 0 % | 0 | 0 | 0

### Detailed technical debt

Reliability|Security|Maintainability|Total
---|---|---|---
-|-|0d 0h 10min|0d 0h 10min


### Metrics Range

\ | Cyclomatic Complexity | Cognitive Complexity | Lines of code per file | Coverage | Comment density (%) | Duplication (%)
:---|:---:|:---:|:---:|:---:|:---:|:---:
Min | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0
Max | 130.0 | 91.0 | 1535.0 | 100.0 | 26.3 | 0.0

### Volume

Language|Number
---|---
Python|1535
Total|1535


## Issues

### Issues count by severity and types

Type / Severity|INFO|MINOR|MAJOR|CRITICAL|BLOCKER
---|---|---|---|---|---
BUG|0|0|0|0|0
VULNERABILITY|0|0|0|0|0
CODE_SMELL|0|0|1|1|0


### Issues List

Name|Description|Type|Severity|Number
---|---|---|---|---
"SystemExit" should be re-raised|SystemExit&nbsp;is raised when sys.exit() is called. This exception is expected to propagate up until the <br /> application stops. It is ok to catch it when a clean-up is necessary but it should be raised again immediately. <br /> A bare except: statement, i.e. an <br /> except without any exception class, is equivalent to except BaseException. Both statements will catch every <br /> exception, including SystemExit. It is recommended to catch instead a specific exception. If it is not possible, the exception should be <br /> raised again. <br /> Note that it is also a good idea to reraise the KeyboardInterrupt exception. <br /> This rule raises an issue when a bare except:, an except BaseException or an except SystemExit don’t reraise <br /> the exception caught. <br /> Noncompliant Code Example <br />  <br /> try: <br />     open("foo.txt", "r") <br /> except SystemExit:  # Noncompliant <br />     pass <br /> except KeyboardInterrupt:  # No issue raised but be careful when you do this <br />     pass <br />  <br /> try: <br />     open("bar.txt", "r") <br /> except BaseException:  # Noncompliant <br />     pass <br /> except:  # Noncompliant <br />     pass <br />  <br /> Compliant Solution <br />  <br /> try: <br />     open("foo.txt", "r") <br /> except SystemExit: <br />     # clean-up <br />     raise <br /> except KeyboardInterrupt: <br />     # clean-up <br />     raise <br />  <br /> try: <br />     open("bar.txt", "r") <br /> except BaseException as e: <br />     # clean-up <br />     raise e <br /> except: # Noncompliant <br />     # clean-up <br />     raise <br />  <br /> # or use a more specific exception <br />  <br /> try: <br />     open("bar.txt", "r") <br /> except FileNotFoundError: <br />     # process the exception <br />  <br /> See <br />  <br />    PEP 352 - Required Superclass for Exceptions  <br />    Python Documentation - Built-in exceptions  <br />    Python Documentation - The try statement <br />    <br />    MITRE, CWE-391 - Unchecked Error Condition  <br /> |CODE_SMELL|CRITICAL|1
Collapsible "if" statements should be merged|Merging collapsible if statements increases the code’s readability. <br /> Noncompliant Code Example <br />  <br /> if condition1: <br />     if condition2: <br />         # ... <br />  <br /> Compliant Solution <br />  <br /> if condition1 and condition2: <br />     # ... <br /> |CODE_SMELL|MAJOR|1


## Security Hotspots

### Security hotspots count by category and priority

Category / Priority|LOW|MEDIUM|HIGH
---|---|---|---
LDAP Injection|0|0|0
Object Injection|0|0|0
Server-Side Request Forgery (SSRF)|0|0|0
XML External Entity (XXE)|0|0|0
Insecure Configuration|0|0|0
XPath Injection|0|0|0
Authentication|0|0|0
Weak Cryptography|0|0|0
Denial of Service (DoS)|0|0|0
Log Injection|0|0|0
Cross-Site Request Forgery (CSRF)|0|0|0
Open Redirect|0|0|0
Permission|0|0|0
SQL Injection|0|0|0
Encryption of Sensitive Data|0|0|0
Traceability|0|0|0
Buffer Overflow|0|0|0
File Manipulation|0|0|0
Code Injection (RCE)|0|0|0
Cross-Site Scripting (XSS)|0|0|0
Command Injection|0|0|0
Path Traversal Injection|0|0|0
HTTP Response Splitting|0|0|0
Others|0|0|0


### Security hotspots

